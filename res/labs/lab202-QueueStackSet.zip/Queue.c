#include "Queue.h"
#include<assert.h>

Queue initializeQueue(void)
{
	return 0;	// Ers�tt med r�tt returv�rde
}

int queueIsEmpty(const Queue queue)
{
	return 0;	// Ers�tt med r�tt returv�rde
}

int queueIsFull(const Queue queue)
{
	return 0;	// Ers�tt med r�tt returv�rde
}

void enqueue(Queue* queue, const Data data)
{
	// Precondition: k�n �r ej full
}

void dequeue(Queue* queue)
{
	// Precondition: k�n �r ej tom
}

Data front(const Queue queue)
{
	// Precondition: k�n �r ej tom
	return 0;	// Ers�tt med r�tt returv�rde
}
