#include "Set.h"
#include <assert.h>


Set initializeSet(void)
{
	return 0; // Ers�tt med r�tt returv�rde
}

void addToSet(Set* set, const Data element)
{
	// Precondition: set �r inte full

	// Tips: t�nk p� att inte l�gga till elementet om det redan finns i *set

	// Postcondition: 'element' finns i set (tips: anv�nd isInSet() f�r att verifiera)
}

void removeFromSet(Set* set, const Data element)
{
	// Postcondition: 'element' finns INTE i set (tips: anv�nd isInSet() f�r att verifiera)
}

int isSetFull(const Set set)
{
	return 0; // Ers�tt med r�tt returv�rde
}

int isInSet(const Set set, const Data element)
{
	return 0; // Ers�tt med r�tt returv�rde
}


