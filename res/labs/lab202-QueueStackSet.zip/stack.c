#include "stack.h"
#include<assert.h>


Stack initializeStack(void)
{
	return 0; // Ers�tt denna rad med r�tt returv�rde
}

int stackIsEmpty(const Stack stack)
{
	return 0; // Ers�tt denna rad med r�tt returv�rde
}

int stackIsFull(const Stack stack)
{
	return 0; // Ers�tt denna rad med r�tt returv�rde
}

void push(Stack* stack, const Data data)
{
	// Precondition: stacken f�r inte vara full
	// Postcondition 'data' ligger �verst p� stacken
}

void pop(Stack* stack)
{
	// Precondition: stacken f�r inte vara tom
}

Data peekStack(const Stack stack)
{
	// Precondition: stacken f�r inte vara tom
	return 0; // Ers'tt denna rad med r�tt returv�rde
}
